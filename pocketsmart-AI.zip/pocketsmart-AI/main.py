import os
import json
import base64
import sqlite3
from datetime import datetime, timedelta, timezone
from urllib.parse import quote_plus

import httpx
import jwt

from dotenv import load_dotenv
from passlib.context import CryptContext

from fastapi import (
    FastAPI,
    Request,
    Form,
    UploadFile,
    File
)

from fastapi.responses import (
    HTMLResponse,
    RedirectResponse,
    JSONResponse
)

from fastapi.staticfiles import StaticFiles


# ============================================================
# CONFIGURATION
# ============================================================

load_dotenv()

APP_NAME = os.getenv(
    "APP_NAME",
    "PocketSmart AI"
)

SECRET_KEY = os.getenv(
    "SECRET_KEY",
    "pocketsmart-secret-key"
)

GEMINI_API_KEY = os.getenv(
    "GEMINI_API_KEY",
    ""
)

GEMINI_MODEL = os.getenv(
    "GEMINI_MODEL",
    "gemini-1.5-flash"
)

DEMO_MODE = os.getenv(
    "DEMO_MODE",
    "true"
).lower() == "true"


DATABASE = "pocketsmart.db"

pwd_context = CryptContext(
    schemes=["bcrypt"],
    deprecated="auto"
)


# ============================================================
# FASTAPI APP
# ============================================================

app = FastAPI(
    title=APP_NAME,
    description="Smart Budget & Recommendation Assistant",
    version="1.0.0"
)


# ============================================================
# DATABASE
# ============================================================

def get_db():

    connection = sqlite3.connect(
        DATABASE,
        check_same_thread=False
    )

    connection.row_factory = sqlite3.Row

    return connection


def init_database():

    db = get_db()

    cursor = db.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            planner_type TEXT NOT NULL,
            request_data TEXT NOT NULL,
            response_data TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id)
            REFERENCES users(id)
        )
    """)

    db.commit()

    db.close()


init_database()


# ============================================================
# PASSWORD FUNCTIONS
# ============================================================

def hash_password(password):

    return pwd_context.hash(password)


def verify_password(
    password,
    hashed_password
):

    return pwd_context.verify(
        password,
        hashed_password
    )


# ============================================================
# JWT FUNCTIONS
# ============================================================

def create_token(user_id):

    expiration = (
        datetime.now(timezone.utc)
        + timedelta(hours=24)
    )

    payload = {
        "sub": str(user_id),
        "exp": expiration
    }

    return jwt.encode(
        payload,
        SECRET_KEY,
        algorithm="HS256"
    )


def get_user_id(request: Request):

    token = request.cookies.get(
        "access_token"
    )

    if not token:
        return None

    try:

        payload = jwt.decode(
            token,
            SECRET_KEY,
            algorithms=["HS256"]
        )

        return int(payload["sub"])

    except Exception:

        return None


def get_current_user(request: Request):

    user_id = get_user_id(request)

    if not user_id:
        return None

    db = get_db()

    user = db.execute(
        "SELECT id,name,email FROM users WHERE id=?",
        (user_id,)
    ).fetchone()

    db.close()

    if not user:
        return None

    return dict(user)


# ============================================================
# LINK BUILDERS
# ============================================================

def amazon_link(product):

    return (
        "https://www.amazon.in/s?k="
        + quote_plus(product)
    )


def flipkart_link(product):

    return (
        "https://www.flipkart.com/search?q="
        + quote_plus(product)
    )


def ikea_link(product):

    return (
        "https://www.ikea.com/in/en/search/"
        "?q="
        + quote_plus(product)
    )


def swiggy_link(product):

    return (
        "https://www.swiggy.com/search?query="
        + quote_plus(product)
    )


def zomato_link(product):

    return (
        "https://www.zomato.com/search?q="
        + quote_plus(product)
    )


def oyo_link(product):

    return (
        "https://www.oyorooms.com/search?location="
        + quote_plus(product)
    )


def product_link(
    platform,
    product
):

    platform = platform.lower()

    if platform == "amazon":
        return amazon_link(product)

    if platform == "flipkart":
        return flipkart_link(product)

    if platform == "ikea":
        return ikea_link(product)

    if platform == "swiggy":
        return swiggy_link(product)

    if platform == "zomato":
        return zomato_link(product)

    if platform == "oyo":
        return oyo_link(product)

    return amazon_link(product)


# ============================================================
# FALLBACK RECOMMENDATIONS
# ============================================================

def home_fallback(data):

    budget = float(data["budget"])

    return {
        "planner": "Home Planner",
        "budget": budget,
        "summary": (
            "A practical home plan has been created "
            "within your selected budget."
        ),
        "budget_allocation": {
            "Furniture": round(budget * 0.35, 2),
            "Lighting": round(budget * 0.15, 2),
            "Fans": round(budget * 0.15, 2),
            "Decor": round(budget * 0.20, 2),
            "Other": round(budget * 0.15, 2)
        },
        "recommendations": [

            {
                "name": "Modern LED Ceiling Light",
                "category": "Lighting",
                "platform": "Amazon",
                "estimated_price": 1499,
                "reason": (
                    "Suitable for modern room interiors "
                    "and energy efficient."
                ),
                "search_url": amazon_link(
                    "modern LED ceiling light"
                )
            },

            {
                "name": "Energy Efficient Ceiling Fan",
                "category": "Fan",
                "platform": "Amazon",
                "estimated_price": 2499,
                "reason": (
                    "Useful for regular home use "
                    "and comfortable airflow."
                ),
                "search_url": amazon_link(
                    "energy efficient ceiling fan"
                )
            },

            {
                "name": "Compact Study / Side Table",
                "category": "Furniture",
                "platform": "IKEA",
                "estimated_price": 3999,
                "reason": (
                    "Compact furniture option "
                    "for limited spaces."
                ),
                "search_url": ikea_link(
                    "small table"
                )
            },

            {
                "name": "Decorative Indoor Plant",
                "category": "Decor",
                "platform": "Flipkart",
                "estimated_price": 799,
                "reason": (
                    "Adds a simple decorative element "
                    "to the room."
                ),
                "search_url": flipkart_link(
                    "indoor decorative plant"
                )
            }
        ]
    }


def party_fallback(data):

    budget = float(data["budget"])
    guests = int(data["guests"])

    return {
        "planner": "Party Planner",
        "budget": budget,
        "summary": (
            f"A party plan for approximately {guests} guests "
            "has been created."
        ),
        "budget_allocation": {
            "Food": round(budget * 0.45, 2),
            "Decoration": round(budget * 0.20, 2),
            "Venue": round(budget * 0.20, 2),
            "Entertainment": round(budget * 0.10, 2),
            "Other": round(budget * 0.05, 2)
        },
        "recommendations": [

            {
                "name": "Party Catering",
                "category": "Food",
                "platform": "Swiggy",
                "estimated_price": round(
                    budget * 0.45,
                    2
                ),
                "reason": (
                    "Food allocation based on "
                    "guest count and total budget."
                ),
                "search_url": swiggy_link(
                    "party catering"
                )
            },

            {
                "name": "Party Food & Restaurants",
                "category": "Food",
                "platform": "Zomato",
                "estimated_price": round(
                    budget * 0.45,
                    2
                ),
                "reason": (
                    "Useful for comparing nearby "
                    "food and restaurant options."
                ),
                "search_url": zomato_link(
                    "party food"
                )
            },

            {
                "name": "Party Decorations",
                "category": "Decoration",
                "platform": "Amazon",
                "estimated_price": round(
                    budget * 0.20,
                    2
                ),
                "reason": (
                    "Basic decoration items suitable "
                    "for the selected event."
                ),
                "search_url": amazon_link(
                    "party decoration kit"
                )
            },

            {
                "name": "Event Stay / Venue Search",
                "category": "Venue",
                "platform": "OYO",
                "estimated_price": round(
                    budget * 0.20,
                    2
                ),
                "reason": (
                    "Can be used to explore "
                    "venue or stay options."
                ),
                "search_url": oyo_link(
                    data.get("venue", "nearby")
                )
            }
        ]
    }


def jewelry_fallback(data):

    budget = float(data["budget"])

    style = data.get(
        "style",
        "Traditional"
    )

    occasion = data.get(
        "occasion",
        "Special Occasion"
    )

    return {
        "planner": "Jewelry Planner",
        "budget": budget,
        "summary": (
            f"Jewelry suggestions for a {occasion} "
            f"with a {style} style preference."
        ),
        "budget_allocation": {
            "Main Jewelry": round(
                budget * 0.60,
                2
            ),
            "Earrings": round(
                budget * 0.20,
                2
            ),
            "Accessories": round(
                budget * 0.10,
                2
            ),
            "Reserve": round(
                budget * 0.10,
                2
            )
        },
        "recommendations": [

            {
                "name": f"{style} Necklace Set",
                "category": "Necklace",
                "platform": "Amazon",
                "estimated_price": round(
                    budget * 0.60,
                    2
                ),
                "reason": (
                    "Selected to match the requested "
                    f"{style} style."
                ),
                "search_url": amazon_link(
                    f"{style} necklace set"
                )
            },

            {
                "name": "Matching Earrings",
                "category": "Earrings",
                "platform": "Flipkart",
                "estimated_price": round(
                    budget * 0.20,
                    2
                ),
                "reason": (
                    "A matching earring option "
                    "for the selected occasion."
                ),
                "search_url": flipkart_link(
                    f"{style} earrings"
                )
            },

            {
                "name": "Elegant Bracelet",
                "category": "Bracelet",
                "platform": "Amazon",
                "estimated_price": round(
                    budget * 0.10,
                    2
                ),
                "reason": (
                    "Can complement the overall "
                    "jewelry combination."
                ),
                "search_url": amazon_link(
                    f"{style} bracelet"
                )
            }
        ]
    }


# ============================================================
# GEMINI API
# ============================================================

def clean_json(text):

    text = text.strip()

    if text.startswith("```json"):
        text = text[7:]

    if text.startswith("```"):
        text = text[3:]

    if text.endswith("```"):
        text = text[:-3]

    return text.strip()


async def call_gemini(
    prompt,
    image_bytes=None,
    mime_type=None
):

    if not GEMINI_API_KEY:
        raise Exception(
            "Gemini API key is missing."
        )

    url = (
        "https://generativelanguage.googleapis.com/"
        "v1beta/models/"
        f"{GEMINI_MODEL}:generateContent"
        f"?key={GEMINI_API_KEY}"
    )

    parts = [
        {
            "text": prompt
        }
    ]

    if image_bytes:

        encoded = base64.b64encode(
            image_bytes
        ).decode("utf-8")

        parts.append(
            {
                "inline_data": {
                    "mime_type": mime_type or "image/jpeg",
                    "data": encoded
                }
            }
        )

    body = {
        "contents": [
            {
                "parts": parts
            }
        ],
        "generationConfig": {
            "temperature": 0.7,
            "responseMimeType": "application/json"
        }
    }

    async with httpx.AsyncClient(
        timeout=60
    ) as client:

        response = await client.post(
            url,
            json=body
        )

        if response.status_code != 200:

            raise Exception(
                f"Gemini API error: "
                f"{response.status_code} "
                f"{response.text}"
            )

        result = response.json()

    candidates = result.get(
        "candidates",
        []
    )

    if not candidates:
        raise Exception(
            "Gemini returned no candidates."
        )

    text = (
        candidates[0]
        .get("content", {})
        .get("parts", [{}])[0]
        .get("text", "")
    )

    if not text:
        raise Exception(
            "Gemini returned empty response."
        )

    return json.loads(
        clean_json(text)
    )


# ============================================================
# AI GENERATORS
# ============================================================

async def generate_home(data):

    if DEMO_MODE:

        return home_fallback(data)

    prompt = f"""
You are PocketSmart AI, a smart budget recommendation assistant.

Create a personalized home planning recommendation.

User requirements:

Budget: ₹{data["budget"]}
Room type: {data["room_type"]}
Style: {data["style"]}
Lights: {data["lights"]}
Fans: {data["fans"]}
Tables: {data["tables"]}
Chairs: {data["chairs"]}
Decoration items: {data["decor_items"]}

Return ONLY valid JSON.

Use exactly this structure:

{{
  "planner": "Home Planner",
  "budget": number,
  "summary": "short summary",
  "budget_allocation": {{
      "Furniture": number,
      "Lighting": number,
      "Fans": number,
      "Decor": number,
      "Other": number
  }},
  "recommendations": [
    {{
      "name": "product name",
      "category": "category",
      "platform": "Amazon",
      "estimated_price": number,
      "reason": "reason",
      "search_url": "https://www.amazon.in/"
    }}
  ]
}}

Recommendations should be practical and stay within the budget.
Platforms may include Amazon, Flipkart and IKEA.
"""

    try:

        return await call_gemini(prompt)

    except Exception:

        return home_fallback(data)


async def generate_party(data):

    if DEMO_MODE:

        return party_fallback(data)

    prompt = f"""
You are PocketSmart AI.

Create a personalized party planning recommendation.

Budget: ₹{data["budget"]}
Event type: {data["event_type"]}
Guests: {data["guests"]}
Venue: {data["venue"]}
Food preference: {data["food_preference"]}
Decoration style: {data["decoration_style"]}

Return ONLY valid JSON.

Structure:

{{
  "planner": "Party Planner",
  "budget": number,
  "summary": "short summary",
  "budget_allocation": {{
      "Food": number,
      "Decoration": number,
      "Venue": number,
      "Entertainment": number,
      "Other": number
  }},
  "recommendations": [
    {{
      "name": "recommendation",
      "category": "category",
      "platform": "Swiggy",
      "estimated_price": number,
      "reason": "reason",
      "search_url": "https://www.swiggy.com/"
    }}
  ]
}}

Use platforms such as Swiggy, Zomato, Amazon and OYO.
Stay within the given budget.
"""

    try:

        return await call_gemini(prompt)

    except Exception:

        return party_fallback(data)


async def generate_jewelry(
    data,
    image_bytes=None,
    mime_type=None
):

    if DEMO_MODE:

        return jewelry_fallback(data)

    prompt = f"""
You are PocketSmart AI, a jewelry recommendation assistant.

Analyze the user's requirements and, if an image is provided,
analyze the outfit's visible colors and overall aesthetic.

Budget: ₹{data["budget"]}
Occasion: {data["occasion"]}
Style: {data["style"]}
Outfit color: {data["outfit_color"]}
Outfit description: {data["outfit_description"]}

Give practical jewelry recommendations.

Return ONLY valid JSON.

Structure:

{{
  "planner": "Jewelry Planner",
  "budget": number,
  "summary": "short summary",
  "budget_allocation": {{
      "Main Jewelry": number,
      "Earrings": number,
      "Accessories": number,
      "Reserve": number
  }},
  "recommendations": [
    {{
      "name": "jewelry item",
      "category": "category",
      "platform": "Amazon",
      "estimated_price": number,
      "reason": "reason",
      "search_url": "https://www.amazon.in/"
    }}
  ]
}}

Use Amazon and Flipkart as shopping platforms.
Stay within the budget.
"""

    try:

        return await call_gemini(
            prompt,
            image_bytes,
            mime_type
        )

    except Exception:

        return jewelry_fallback(data)


# ============================================================
# SAVE HISTORY
# ============================================================

def save_history(
    user_id,
    planner_type,
    request_data,
    response_data
):

    db = get_db()

    db.execute(
        """
        INSERT INTO history
        (
            user_id,
            planner_type,
            request_data,
            response_data,
            created_at
        )
        VALUES (?, ?, ?, ?, ?)
        """,
        (
            user_id,
            planner_type,
            json.dumps(request_data),
            json.dumps(response_data),
            datetime.now().isoformat()
        )
    )

    db.commit()

    db.close()


# ============================================================
# HTML HELPER
# ============================================================

def page(
    title,
    body,
    user=None
):

    user_nav = ""

    if user:

        user_nav = f"""
            <a href="/dashboard">Dashboard</a>
            <a href="/history">History</a>

            <form action="/logout"
                  method="post"
                  style="display:inline">

                <button class="nav-button">
                    Logout
                </button>

            </form>
        """

    else:

        user_nav = """
            <a href="/login">Login</a>
            <a href="/register">Register</a>
        """

    return f"""
<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>{title} - PocketSmart AI</title>

<style>

* {{
    box-sizing: border-box;
}}

body {{
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f5f7fb;
    color: #1f2937;
}}

nav {{
    background: white;
    padding: 18px 6%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #ddd;
}}

.logo {{
    font-size: 22px;
    font-weight: bold;
}}

nav div {{
    display: flex;
    align-items: center;
    gap: 18px;
}}

nav a {{
    color: #111827;
    text-decoration: none;
    font-weight: 600;
}}

.nav-button {{
    border: 0;
    background: none;
    font-weight: 600;
    cursor: pointer;
    font-size: 15px;
}}

.container {{
    max-width: 1200px;
    margin: auto;
    padding: 45px 20px;
}}

.hero {{
    background: white;
    padding: 80px 8%;
}}

.hero h1 {{
    font-size: 56px;
    margin: 15px 0;
}}

.hero p {{
    max-width: 650px;
    font-size: 19px;
    color: #6b7280;
}}

.btn {{
    display: inline-block;
    padding: 12px 20px;
    background: #111827;
    color: white;
    border: 0;
    border-radius: 8px;
    text-decoration: none;
    cursor: pointer;
    font-weight: bold;
}}

.btn-light {{
    background: #e5e7eb;
    color: #111827;
}}

.grid {{
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 22px;
}}

.card {{
    background: white;
    border: 1px solid #e5e7eb;
    border-radius: 14px;
    padding: 28px;
}}

.card h2 {{
    margin-top: 10px;
}}

.icon {{
    font-size: 42px;
}}

.form-card {{
    max-width: 650px;
    margin: auto;
    background: white;
    padding: 35px;
    border-radius: 15px;
}}

label {{
    display: block;
    margin-top: 16px;
    margin-bottom: 6px;
    font-weight: bold;
}}

input,
select,
textarea {{
    width: 100%;
    padding: 12px;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    font-size: 15px;
}}

button {{
    margin-top: 20px;
}}

.full {{
    width: 100%;
}}

.two {{
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}}

.result {{
    margin-top: 30px;
}}

.result-card {{
    background: white;
    border-radius: 14px;
    padding: 25px;
    margin-bottom: 18px;
    border: 1px solid #e5e7eb;
}}

.recommendation {{
    border: 1px solid #ddd;
    padding: 18px;
    border-radius: 10px;
    margin-top: 15px;
}}

.price {{
    font-size: 20px;
    font-weight: bold;
}}

.badge {{
    display: inline-block;
    background: #eef2ff;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: bold;
}}

.allocation {{
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
}}

.allocation div {{
    background: #f3f4f6;
    padding: 12px;
    border-radius: 8px;
}}

.error {{
    background: #fee2e2;
    color: #991b1b;
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 15px;
}}

.success {{
    background: #dcfce7;
    color: #166534;
    padding: 12px;
    border-radius: 8px;
}}

.history {{
    background: white;
    padding: 20px;
    margin-bottom: 15px;
    border-radius: 12px;
    border: 1px solid #ddd;
}}

footer {{
    margin-top: 60px;
    background: #111827;
    color: white;
    padding: 35px 8%;
}}

@media(max-width:800px) {{

    .grid {{
        grid-template-columns: 1fr;
    }}

    .hero h1 {{
        font-size: 40px;
    }}

    .two {{
        grid-template-columns: 1fr;
    }}

    .allocation {{
        grid-template-columns: 1fr;
    }}

    nav {{
        flex-direction: column;
        gap: 15px;
    }}

}}

</style>

</head>

<body>

<nav>

    <div class="logo">
        💰 PocketSmart AI
    </div>

    <div>

        <a href="/">Home</a>

        <a href="/home-planner">
            Home Planner
        </a>

        <a href="/party-planner">
            Party Planner
        </a>

        <a href="/jewelry-planner">
            Jewelry
        </a>

        {user_nav}

    </div>

</nav>

{body}

<footer>

    <h3>💰 PocketSmart AI</h3>

    <p>
        Your Smart Budget & Recommendation Assistant
    </p>

    <p>
        © 2026 PocketSmart AI
    </p>

</footer>

</body>

</html>
"""


# ============================================================
# HOME PAGE
# ============================================================

@app.get(
    "/",
    response_class=HTMLResponse
)
async def home(request: Request):

    user = get_current_user(request)

    body = """

<section class="hero">

    <span class="badge">
        ✨ Generative AI Powered
    </span>

    <h1>
        Plan Smart.<br>
        Spend Smart.
    </h1>

    <p>
        PocketSmart AI is your smart budget and
        recommendation assistant for home planning,
        party planning and jewelry shopping.
    </p>

    <br>

    <a href="/home-planner"
       class="btn">
        Start Planning
    </a>

</section>


<div class="container">

    <h2>
        What can PocketSmart AI do?
    </h2>

    <div class="grid">

        <div class="card">

            <div class="icon">
                🏠
            </div>

            <h2>
                Home Planner
            </h2>

            <p>
                Plan furniture, lights, fans,
                tables, chairs and decorations
                according to your budget.
            </p>

            <a href="/home-planner"
               class="btn">
                Try Home Planner
            </a>

        </div>


        <div class="card">

            <div class="icon">
                🎉
            </div>

            <h2>
                Party Planner
            </h2>

            <p>
                Plan food, venue, decoration
                and entertainment for your event.
            </p>

            <a href="/party-planner"
               class="btn">
                Try Party Planner
            </a>

        </div>


        <div class="card">

            <div class="icon">
                💎
            </div>

            <h2>
                Jewelry Planner
            </h2>

            <p>
                Find jewelry recommendations based
                on budget, occasion, style and outfit.
            </p>

            <a href="/jewelry-planner"
               class="btn">
                Try Jewelry Planner
            </a>

        </div>

    </div>

</div>
"""

    return page(
        "Home",
        body,
        user
    )


# ============================================================
# REGISTER
# ============================================================

@app.get(
    "/register",
    response_class=HTMLResponse
)
async def register_page():

    body = """

<div class="container">

<div class="form-card">

<h1>Create Account</h1>

<p>
Create your PocketSmart AI account.
</p>

<form action="/register"
      method="post">

<label>
Name
</label>

<input
    name="name"
    required
    minlength="2"
    placeholder="Enter your name"
>


<label>
Email
</label>

<input
    name="email"
    type="email"
    required
    placeholder="Enter your email"
>


<label>
Password
</label>

<input
    name="password"
    type="password"
    required
    minlength="6"
    placeholder="Minimum 6 characters"
>


<button class="btn full"
        type="submit">

Create Account

</button>

</form>

<br>

<p>
Already have an account?
<a href="/login">
Login
</a>
</p>

</div>

</div>
"""

    return page(
        "Register",
        body
    )


@app.post("/register")
async def register(
    name: str = Form(...),
    email: str = Form(...),
    password: str = Form(...)
):

    name = name.strip()
    email = email.strip().lower()

    if len(password) < 6:

        return HTMLResponse(
            """
            <h2>Password must contain
            at least 6 characters.</h2>
            <a href="/register">Go back</a>
            """,
            status_code=400
        )

    db = get_db()

    existing = db.execute(
        "SELECT id FROM users WHERE email=?",
        (email,)
    ).fetchone()

    if existing:

        db.close()

        return HTMLResponse(
            """
            <h2>Email already registered.</h2>
            <a href="/login">Login</a>
            """,
            status_code=400
        )

    hashed = hash_password(password)

    cursor = db.execute(
        """
        INSERT INTO users
        (name,email,password,created_at)
        VALUES (?,?,?,?)
        """,
        (
            name,
            email,
            hashed,
            datetime.now().isoformat()
        )
    )

    db.commit()

    user_id = cursor.lastrowid

    db.close()

    token = create_token(user_id)

    response = RedirectResponse(
        "/dashboard",
        status_code=303
    )

    response.set_cookie(
        "access_token",
        token,
        httponly=True,
        max_age=86400,
        samesite="lax"
    )

    return response


# ============================================================
# LOGIN
# ============================================================

@app.get(
    "/login",
    response_class=HTMLResponse
)
async def login_page():

    body = """

<div class="container">

<div class="form-card">

<h1>Login</h1>

<p>
Login to your PocketSmart AI account.
</p>

<form action="/login"
      method="post">

<label>
Email
</label>

<input
    name="email"
    type="email"
    required
>


<label>
Password
</label>

<input
    name="password"
    type="password"
    required
>


<button class="btn full"
        type="submit">

Login

</button>

</form>

<br>

<p>
Don't have an account?
<a href="/register">
Create Account
</a>
</p>

</div>

</div>
"""

    return page(
        "Login",
        body
    )


@app.post("/login")
async def login(
    email: str = Form(...),
    password: str = Form(...)
):

    email = email.strip().lower()

    db = get_db()

    user = db.execute(
        "SELECT * FROM users WHERE email=?",
        (email,)
    ).fetchone()

    db.close()

    if not user or not verify_password(
        password,
        user["password"]
    ):

        return HTMLResponse(
            """
            <h2>
            Invalid email or password.
            </h2>

            <a href="/login">
            Try again
            </a>
            """,
            status_code=401
        )

    token = create_token(
        user["id"]
    )

    response = RedirectResponse(
        "/dashboard",
        status_code=303
    )

    response.set_cookie(
        "access_token",
        token,
        httponly=True,
        max_age=86400,
        samesite="lax"
    )

    return response


# ============================================================
# LOGOUT
# ============================================================

@app.post("/logout")
async def logout():

    response = RedirectResponse(
        "/",
        status_code=303
    )

    response.delete_cookie(
        "access_token"
    )

    return response


# ============================================================
# DASHBOARD
# ============================================================

@app.get(
    "/dashboard",
    response_class=HTMLResponse
)
async def dashboard(request: Request):

    user = get_current_user(request)

    if not user:

        return RedirectResponse(
            "/login",
            status_code=303
        )

    body = f"""

<div class="container">

<h1>
Hello, {user["name"]}! 👋
</h1>

<p>
Choose what you want to plan today.
</p>

<br>

<div class="grid">

<div class="card">

<div class="icon">
🏠
</div>

<h2>
Home Planner
</h2>

<p>
Create a budget-friendly home plan.
</p>

<a href="/home-planner"
   class="btn">
Start
</a>

</div>


<div class="card">

<div class="icon">
🎉
</div>

<h2>
Party Planner
</h2>

<p>
Plan your party expenses.
</p>

<a href="/party-planner"
   class="btn">
Start
</a>

</div>


<div class="card">

<div class="icon">
💎
</div>

<h2>
Jewelry Planner
</h2>

<p>
Find jewelry recommendations.
</p>

<a href="/jewelry-planner"
   class="btn">
Start
</a>

</div>

</div>

<br><br>

<a href="/history"
   class="btn btn-light">
View History
</a>

</div>
"""

    return page(
        "Dashboard",
        body,
        user
    )


# ============================================================
# HOME PLANNER PAGE
# ============================================================

@app.get(
    "/home-planner",
    response_class=HTMLResponse
)
async def home_planner(request: Request):

    user = get_current_user(request)

    body = """

<div class="container">

<div class="form-card">

<h1>
🏠 Home Planner
</h1>

<p>
Enter your requirements and generate
a smart home recommendation.
</p>

<form id="homeForm">

<label>
Budget (₹)
</label>

<input
    name="budget"
    type="number"
    min="1"
    required
    placeholder="Example: 50000"
>


<label>
Room Type
</label>

<select name="room_type">

<option>
Living Room
</option>

<option>
Bedroom
</option>

<option>
Kitchen
</option>

<option>
Hall
</option>

<option>
Office
</option>

</select>


<label>
Style
</label>

<select name="style">

<option>
Modern
</option>

<option>
Minimalist
</option>

<option>
Traditional
</option>

<option>
Luxury
</option>

</select>


<div class="two">

<div>

<label>
Lights
</label>

<input
    name="lights"
    type="number"
    value="0"
    min="0"
>

</div>

<div>

<label>
Fans
</label>

<input
    name="fans"
    type="number"
    value="0"
    min="0"
>

</div>

</div>


<div class="two">

<div>

<label>
Tables
</label>

<input
    name="tables"
    type="number"
    value="0"
    min="0"
>

</div>

<div>

<label>
Chairs
</label>

<input
    name="chairs"
    type="number"
    value="0"
    min="0"
>

</div>

</div>


<label>
Decoration Items
</label>

<input
    name="decor_items"
    type="number"
    value="0"
    min="0"
>


<button
    type="submit"
    class="btn full">

🤖 Generate AI Recommendation

</button>

</form>

</div>


<div id="result"
     class="result">

</div>

</div>


<script>
function renderRecommendation(data) {
    const result = document.getElementById("result");

    if (!result) {
        return;
    }

    let html = `
        <div class="card">
            <h2>🤖 AI Recommendation</h2>
    `;

    if (data.summary) {
        html += `
            <p>${data.summary}</p>
        `;
    }

    if (data.budget_allocation) {
        html += `
            <h3>💰 Budget Allocation</h3>
            <ul>
        `;

        for (const [key, value] of Object.entries(data.budget_allocation)) {
            html += `<li><strong>${key}:</strong> ₹${value}</li>`;
        }

        html += `</ul>`;
    }

    if (data.recommendations && Array.isArray(data.recommendations)) {
        html += `<h3>🛍️ Recommended Items</h3>`;

        data.recommendations.forEach(item => {
            html += `
                <div class="card">
                    <h4>${item.name || "Recommended Item"}</h4>
                    <p>${item.description || ""}</p>
                    <p><strong>Price:</strong> ₹${item.price || "N/A"}</p>
                </div>
            `;
        });
    }

    html += `</div>`;

    result.innerHTML = html;
}
document
.getElementById("homeForm")
.addEventListener("submit", async function(e) {

    e.preventDefault();

    const form =
        new FormData(this);

    const data = {};

    form.forEach((value, key) => {

        if([
            "budget",
            "lights",
            "fans",
            "tables",
            "chairs",
            "decor_items"
        ].includes(key)) {

            data[key] = Number(value);

        } else {

            data[key] = value;

        }

    });

    const result =
        document.getElementById("result");

    result.innerHTML =
        "<div class='card'>🤖 Generating recommendation...</div>";

    try {

        const response =
            await fetch(
                "/generate-home",
                {
                    method: "POST",
                    headers: {
                        "Content-Type":
                            "application/json"
                    },
                    body: JSON.stringify(data)
                }
            );

        const json =
            await response.json();

        if(!response.ok) {
            throw new Error(
                json.detail ||
                "Request failed"
            );
        }

        renderRecommendation(
            json,
            result
        );

    } catch(error) {

        result.innerHTML =
            "<div class='error'>" +
            error.message +
            "</div>";

    }

});

</script>
"""

    return page(
        "Home Planner",
        body,
        user
    )


# ============================================================
# PARTY PLANNER PAGE
# ============================================================

@app.get(
    "/party-planner",
    response_class=HTMLResponse
)
async def party_planner(request: Request):

    user = get_current_user(request)

    body = """

<div class="container">

<div class="form-card">

<h1>
🎉 Party Planner
</h1>

<p>
Plan your party within your budget.
</p>

<form id="partyForm">

<label>
Budget (₹)
</label>

<input
    name="budget"
    type="number"
    min="1"
    required
>


<label>
Event Type
</label>

<select name="event_type">

<option>
Birthday
</option>

<option>
Wedding
</option>

<option>
Engagement
</option>

<option>
College Event
</option>

<option>
Family Function
</option>

</select>


<label>
Number of Guests
</label>

<input
    name="guests"
    type="number"
    min="1"
    required
>


<label>
Venue
</label>

<select name="venue">

<option>
Any
</option>

<option>
Home
</option>

<option>
Hall
</option>

<option>
Hotel
</option>

<option>
Outdoor
</option>

</select>


<label>
Food Preference
</label>

<select name="food_preference">

<option>
Mixed
</option>

<option>
Vegetarian
</option>

<option>
Non-Vegetarian
</option>

</select>


<label>
Decoration Style
</label>

<select name="decoration_style">

<option>
Simple
</option>

<option>
Elegant
</option>

<option>
Traditional
</option>

<option>
Luxury
</option>

</select>


<button
    type="submit"
    class="btn full">

🤖 Generate Party Plan

</button>

</form>

</div>


<div id="result"
     class="result">

</div>

</div>


<script>
function renderRecommendation(data) {
    const result = document.getElementById("result");

    if (!result) {
        return;
    }

    let html = `
        <div class="card">
            <h2>🤖 AI Recommendation</h2>
    `;

    if (data.summary) {
        html += `
            <p>${data.summary}</p>
        `;
    }

    if (data.budget_allocation) {
        html += `
            <h3>💰 Budget Allocation</h3>
            <ul>
        `;

        for (const [key, value] of Object.entries(data.budget_allocation)) {
            html += `<li><strong>${key}:</strong> ₹${value}</li>`;
        }

        html += `</ul>`;
    }

    if (data.recommendations && Array.isArray(data.recommendations)) {
        html += `<h3>🛍️ Recommended Items</h3>`;

        data.recommendations.forEach(item => {
            html += `
                <div class="card">
                    <h4>${item.name || "Recommended Item"}</h4>
                    <p>${item.description || ""}</p>
                    <p><strong>Price:</strong> ₹${item.price || "N/A"}</p>
                </div>
            `;
        });
    }

    html += `</div>`;

    result.innerHTML = html;
}
document
.getElementById("partyForm")
.addEventListener("submit", async function(e) {

    e.preventDefault();

    const form =
        new FormData(this);

    const data = {};

    form.forEach((value, key) => {

        if([
            "budget",
            "guests"
        ].includes(key)) {

            data[key] = Number(value);

        } else {

            data[key] = value;

        }

    });

    const result =
        document.getElementById("result");

    result.innerHTML =
        "<div class='card'>🤖 Generating party plan...</div>";

    try {

        const response =
            await fetch(
                "/generate-party",
                {
                    method: "POST",
                    headers: {
                        "Content-Type":
                            "application/json"
                    },
                    body: JSON.stringify(data)
                }
            );

        const json =
            await response.json();

        if(!response.ok) {
            throw new Error(
                json.detail ||
                "Request failed"
            );
        }

        renderRecommendation(
            json,
            result
        );

    } catch(error) {

        result.innerHTML =
            "<div class='error'>" +
            error.message +
            "</div>";

    }

});

</script>
"""

    return page(
        "Party Planner",
        body,
        user
    )


# ============================================================
# JEWELRY PLANNER
# ============================================================

@app.get(
    "/jewelry-planner",
    response_class=HTMLResponse
)
async def jewelry_planner(
    request: Request
):

    user = get_current_user(request)

    body = """

<div class="container">

<div class="form-card">

<h1>
💎 Jewelry Planner
</h1>

<p>
Get jewelry recommendations based on
your budget, occasion, style and outfit.
</p>

<form id="jewelryForm">

<label>
Budget (₹)
</label>

<input
    name="budget"
    type="number"
    min="1"
    required
>


<label>
Occasion
</label>

<select name="occasion">

<option>
Wedding
</option>

<option>
Engagement
</option>

<option>
Birthday
</option>

<option>
Festival
</option>

<option>
College Function
</option>

<option>
Daily Wear
</option>

</select>


<label>
Style
</label>

<select name="style">

<option>
Traditional
</option>

<option>
Modern
</option>

<option>
Minimalist
</option>

<option>
Bridal
</option>

<option>
Elegant
</option>

</select>


<label>
Outfit Color
</label>

<input
    name="outfit_color"
    placeholder="Example: Maroon"
>


<label>
Outfit Description
</label>

<textarea
    name="outfit_description"
    rows="4"
    placeholder="Describe your outfit..."
></textarea>


<label>
Outfit Image (Optional)
</label>

<input
    name="outfit_image"
    type="file"
    accept="image/*"
>


<button
    type="submit"
    class="btn full">

💎 Generate Jewelry Recommendations

</button>

</form>

</div>


<div id="result"
     class="result">

</div>

</div>


<script>
function renderRecommendation(data) {
    const result = document.getElementById("result");

    if (!result) {
        return;
    }

    let html = `
        <div class="card">
            <h2>🤖 AI Recommendation</h2>
    `;

    if (data.summary) {
        html += `
            <p>${data.summary}</p>
        `;
    }

    if (data.budget_allocation) {
        html += `
            <h3>💰 Budget Allocation</h3>
            <ul>
        `;

        for (const [key, value] of Object.entries(data.budget_allocation)) {
            html += `<li><strong>${key}:</strong> ₹${value}</li>`;
        }

        html += `</ul>`;
    }

    if (data.recommendations && Array.isArray(data.recommendations)) {
        html += `<h3>🛍️ Recommended Items</h3>`;

        data.recommendations.forEach(item => {
            html += `
                <div class="card">
                    <h4>${item.name || "Recommended Item"}</h4>
                    <p>${item.description || ""}</p>
                    <p><strong>Price:</strong> ₹${item.price || "N/A"}</p>
                </div>
            `;
        });
    }

    html += `</div>`;

    result.innerHTML = html;
}
document
.getElementById("jewelryForm")
.addEventListener("submit", async function(e) {

    e.preventDefault();

    const form =
        new FormData(this);

    const result =
        document.getElementById("result");

    result.innerHTML =
        "<div class='card'>💎 Analyzing your requirements...</div>";

    try {

        const response =
            await fetch(
                "/generate-jewelry",
                {
                    method: "POST",
                    body: form
                }
            );

        const json =
            await response.json();

        if(!response.ok) {
            throw new Error(
                json.detail ||
                "Request failed"
            );
        }

        renderRecommendation(
            json,
            result
        );

    } catch(error) {

        result.innerHTML =
            "<div class='error'>" +
            error.message +
            "</div>";

    }

});

</script>
"""

    return page(
        "Jewelry Planner",
        body,
        user
    )


# ============================================================
# RECOMMENDATION JAVASCRIPT
# ============================================================

@app.get(
    "/recommendation-script.js"
)
async def recommendation_script():

    script = r"""

function renderRecommendation(data, container) {

    let html = "";

    html += `
        <div class="result-card">

            <span class="badge">
                🤖 AI Recommendation
            </span>

            <h2>
                ${escapeHtml(data.planner)}
            </h2>

            <p>
                ${escapeHtml(data.summary)}
            </p>

            <h3>
                Budget: ₹${Number(data.budget).toLocaleString("en-IN")}
            </h3>

        </div>
    `;


    if(data.budget_allocation) {

        html += `
            <div class="result-card">

                <h2>
                    💰 Budget Allocation
                </h2>

                <div class="allocation">
        `;

        Object.entries(
            data.budget_allocation
        ).forEach(([key, value]) => {

            html += `
                <div>

                    <strong>
                        ${escapeHtml(key)}
                    </strong>

                    <br>

                    ₹${Number(value)
                        .toLocaleString("en-IN")}

                </div>
            `;

        });

        html += `
                </div>

            </div>
        `;

    }


    html += `
        <div class="result-card">

            <h2>
                🛍️ Recommendations
            </h2>
    `;


    if(
        data.recommendations &&
        data.recommendations.length
    ) {

        data.recommendations.forEach(
            item => {

                html += `
                    <div class="recommendation">

                        <span class="badge">
                            ${escapeHtml(item.category)}
                        </span>

                        <h3>
                            ${escapeHtml(item.name)}
                        </h3>

                        <p>
                            Platform:
                            <strong>
                                ${escapeHtml(item.platform)}
                            </strong>
                        </p>

                        <p class="price">
                            ₹${Number(
                                item.estimated_price
                            ).toLocaleString("en-IN")}
                        </p>

                        <p>
                            ${escapeHtml(item.reason)}
                        </p>

                        <a
                            class="btn"
                            href="${escapeHtml(item.search_url)}"
                            target="_blank"
                            rel="noopener noreferrer">

                            View / Search

                        </a>

                    </div>
                `;

            }
        );

    }

    html += `
        </div>
    `;


    container.innerHTML = html;
}


function escapeHtml(value) {

    return String(value || "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");

}

"""

    return HTMLResponse(
        content=script,
        media_type="application/javascript"
    )


# ============================================================
# HOME RECOMMENDATION API
# ============================================================

@app.post("/generate-home")
async def generate_home_api(
    request: Request
):

    try:

        data = await request.json()

        required = [
            "budget",
            "room_type",
            "style",
            "lights",
            "fans",
            "tables",
            "chairs",
            "decor_items"
        ]

        for key in required:

            if key not in data:

                return JSONResponse(
                    {
                        "detail":
                        f"Missing field: {key}"
                    },
                    status_code=400
                )

        if float(data["budget"]) <= 0:

            return JSONResponse(
                {
                    "detail":
                    "Budget must be greater than zero."
                },
                status_code=400
            )

        result = await generate_home(
            data
        )

        user_id = get_user_id(request)

        if user_id:

            save_history(
                user_id,
                "home",
                data,
                result
            )

        return result

    except Exception as error:

        return JSONResponse(
            {
                "detail": str(error)
            },
            status_code=500
        )


# ============================================================
# PARTY RECOMMENDATION API
# ============================================================

@app.post("/generate-party")
async def generate_party_api(
    request: Request
):

    try:

        data = await request.json()

        required = [
            "budget",
            "event_type",
            "guests",
            "venue",
            "food_preference",
            "decoration_style"
        ]

        for key in required:

            if key not in data:

                return JSONResponse(
                    {
                        "detail":
                        f"Missing field: {key}"
                    },
                    status_code=400
                )

        if float(data["budget"]) <= 0:

            return JSONResponse(
                {
                    "detail":
                    "Budget must be greater than zero."
                },
                status_code=400
            )

        if int(data["guests"]) <= 0:

            return JSONResponse(
                {
                    "detail":
                    "Guests must be greater than zero."
                },
                status_code=400
            )

        result = await generate_party(
            data
        )

        user_id = get_user_id(request)

        if user_id:

            save_history(
                user_id,
                "party",
                data,
                result
            )

        return result

    except Exception as error:

        return JSONResponse(
            {
                "detail": str(error)
            },
            status_code=500
        )


# ============================================================
# JEWELRY RECOMMENDATION API
# ============================================================

@app.post("/generate-jewelry")
async def generate_jewelry_api(
    request: Request,
    budget: float = Form(...),
    occasion: str = Form(...),
    style: str = Form(...),
    outfit_color: str = Form(""),
    outfit_description: str = Form(""),
    outfit_image: UploadFile | None = File(None)
):

    try:

        if budget <= 0:

            return JSONResponse(
                {
                    "detail":
                    "Budget must be greater than zero."
                },
                status_code=400
            )

        image_bytes = None
        mime_type = None

        if outfit_image:

            image_bytes = (
                await outfit_image.read()
            )

            mime_type = (
                outfit_image.content_type
                or "image/jpeg"
            )

        data = {
            "budget": budget,
            "occasion": occasion,
            "style": style,
            "outfit_color": outfit_color,
            "outfit_description":
                outfit_description
        }

        result = await generate_jewelry(
            data,
            image_bytes,
            mime_type
        )

        user_id = get_user_id(request)

        if user_id:

            save_history(
                user_id,
                "jewelry",
                data,
                result
            )

        return result

    except Exception as error:

        return JSONResponse(
            {
                "detail": str(error)
            },
            status_code=500
        )


# ============================================================
# HISTORY
# ============================================================

@app.get(
    "/history",
    response_class=HTMLResponse
)
async def history(
    request: Request
):

    user = get_current_user(request)

    if not user:

        return RedirectResponse(
            "/login",
            status_code=303
        )

    db = get_db()

    rows = db.execute(
        """
        SELECT *
        FROM history
        WHERE user_id=?
        ORDER BY id DESC
        """,
        (user["id"],)
    ).fetchall()

    db.close()

    content = ""

    if not rows:

        content = """
        <div class="card">

            <h2>
                📭 No History Yet
            </h2>

            <p>
                Your recommendations will
                appear here.
            </p>

        </div>
        """

    else:

        for row in rows:

            content += f"""

            <div class="history">

                <span class="badge">
                    {row["planner_type"].upper()}
                </span>

                <h3>
                    {row["planner_type"].title()}
                    Recommendation
                </h3>

                <p>
                    Created:
                    {row["created_at"]}
                </p>

                <a
                    class="btn"
                    href="/recommendations-details/{row["id"]}">

                    View Details

                </a>

            </div>

            """

    body = f"""

<div class="container">

<h1>
📜 Recommendation History
</h1>

<p>
Your previous PocketSmart AI recommendations.
</p>

<br>

{content}

</div>
"""

    return page(
        "History",
        body,
        user
    )


# ============================================================
# HISTORY DETAILS
# ============================================================

@app.get(
    "/recommendations-details/{history_id}",
    response_class=HTMLResponse
)
async def history_details(
    request: Request,
    history_id: int
):

    user = get_current_user(request)

    if not user:

        return RedirectResponse(
            "/login",
            status_code=303
        )

    db = get_db()

    row = db.execute(
        """
        SELECT *
        FROM history
        WHERE id=?
        AND user_id=?
        """,
        (
            history_id,
            user["id"]
        )
    ).fetchone()

    db.close()

    if not row:

        return HTMLResponse(
            "<h2>Recommendation not found.</h2>",
            status_code=404
        )

    result = json.loads(
        row["response_data"]
    )

    recommendations_html = ""

    for item in result.get(
        "recommendations",
        []
    ):

        recommendations_html += f"""

        <div class="recommendation">

            <span class="badge">
                {item.get("category", "")}
            </span>

            <h3>
                {item.get("name", "")}
            </h3>

            <p>
                Platform:
                {item.get("platform", "")}
            </p>

            <p class="price">
                ₹{item.get("estimated_price", 0)}
            </p>

            <p>
                {item.get("reason", "")}
            </p>

            <a
                href="{item.get("search_url", "#")}"
                target="_blank"
                class="btn">

                View / Search

            </a>

        </div>

        """

    allocation_html = ""

    for key, value in result.get(
        "budget_allocation",
        {}
    ).items():

        allocation_html += f"""

        <div>

            <strong>
                {key}
            </strong>

            <br>

            ₹{value}

        </div>

        """

    body = f"""

<div class="container">

<h1>
{result.get("planner", "Recommendation")}
</h1>

<p>
{result.get("summary", "")}
</p>

<br>

<div class="result-card">

<h2>
Budget
</h2>

<h2>
₹{result.get("budget", 0)}
</h2>

</div>


<div class="result-card">

<h2>
💰 Budget Allocation
</h2>

<div class="allocation">

{allocation_html}

</div>

</div>


<div class="result-card">

<h2>
🛍️ Recommendations
</h2>

{recommendations_html}

</div>

</div>
"""

    return page(
        "Recommendation",
        body,
        user
    )


# ============================================================
# HEALTH CHECK
# ============================================================

@app.get("/health")
async def health():

    return {
        "status": "ok",
        "application": APP_NAME,
        "demo_mode": DEMO_MODE
    }


@app.get("/startup")
async def startup():

    return {
        "application": APP_NAME,
        "status": "running"
    }


# ============================================================
# SESSION APIs
# ============================================================

@app.get("/session-info")
async def session_info(
    request: Request
):

    user = get_current_user(request)

    return {
        "logged_in": user is not None,
        "user": user
    }


@app.get("/session-data")
async def session_data(
    request: Request
):

    user = get_current_user(request)

    return {
        "user": user
    }


# ============================================================
# RUN
# ============================================================

if __name__ == "__main__":

    import uvicorn

    uvicorn.run(
        "main:app",
        host="127.0.0.1",
        port=8000,
        reload=True
    )