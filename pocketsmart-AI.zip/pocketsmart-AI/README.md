# PocketSmart AI

PocketSmart AI is a Generative AI powered smart budget
and recommendation assistant.

## Features

- User registration
- User login
- Logout
- SQLite database
- Home Planner
- Party Planner
- Jewelry Planner
- Outfit image upload
- Gemini AI integration
- Budget allocation
- Product recommendations
- Recommendation history
- Fallback recommendations
- FastAPI REST APIs

## Requirements

Python 3.10 or newer.

## Installation

Open VS Code terminal.

Create virtual environment:

python -m venv venv

Windows:

venv\Scripts\activate

Install packages:

pip install -r requirements.txt

## Run

python -m uvicorn main:app --reload

Open:

http://127.0.0.1:8000

## Gemini

Initially the application works in DEMO_MODE.

.env:

DEMO_MODE=true

To use Gemini:

GEMINI_API_KEY=YOUR_API_KEY

DEMO_MODE=false

Then restart the application.

## API

GET /

GET /health

GET /startup

GET /session-info

GET /session-data

POST /register

POST /login

POST /logout

POST /generate-home

POST /generate-party

POST /generate-jewelry

GET /history

GET /recommendations-details/{history_id}